# CLITemp

A command line tool for getting complete weather data of a particular geographical area.  
Powered by WeatherBIT API brings all the emergency alerts, historic, current and forecasts of weather data right on the command line with simple commands!  

Maintainer: Shree Vatsa N  
Email : i.mnshreevatsa@gmail.com  

Estimated date avalaibility on PyPI is 1/8/20
