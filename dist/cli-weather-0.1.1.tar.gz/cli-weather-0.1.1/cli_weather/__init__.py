"""
cli-weather

Get fast updates on weather-data right on the command line.
"""

__version__ = "0.1.0"
__author__ = 'Shree Vatsa N'

